const express = require("express");
const router = express.Router();
const accountController = require("../controllers/accountController");
const validation = require("../utilities/account-validation");

router.get("/login", accountController.buildLogin);
router.post(
  "/login",
  validation.loginRules(),
  validation.checkLoginData,
  accountController.loginAccount
);

router.get("/register", accountController.buildRegister);
router.post(
  "/register",
  validation.registrationRules(),
  validation.checkRegData,
  accountController.registerAccount
);

router.get("/manage", accountController.buildAccountManagement);

router.get("/update", accountController.buildUpdateAccount);

router.post(
  "/update",
  validation.updateRules(),
  validation.checkUpdateData,
  accountController.updateAccount
);

router.get("/logout", accountController.logout);

module.exports = router;


